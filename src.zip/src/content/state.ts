export interface LyricsLine {
  time: number;
  endTime?: number | null;
  mainText: string;
  subText?: string;
  isInstrumental?: boolean;
}

export interface RawSubtitleLine {
  start: number;
  end: number;
  text: string;
}

export type LayoutPreset =
  | 'top-left'
  | 'top-center'
  | 'top-right'
  | 'middle-left'
  | 'center'
  | 'middle-right'
  | 'bottom-left'
  | 'bottom-center'
  | 'bottom-right'
  | 'custom';

export type LyricsTextAlign = 'left' | 'center' | 'right';
export type LyricsAnchorY = 'top' | 'center' | 'bottom';
export type VisualMode = 'normal' | 'mirror-spectrum';

export interface UserSettings {
  isEnabled: boolean;
  isManuallyDisabled: boolean;
  fontSize: number | string;
  verticalPos: number;
  horizontalPos: number;
  layoutPreset: LayoutPreset;
  textAlign: LyricsTextAlign;
  anchorY: LyricsAnchorY;
  visibleLines: number;
  lineHeight: number | string;
  primaryLang: string;
  secondaryLang: string;
  fontFamily: 'standard' | 'serif' | 'antique' | 'rounded' | 'hachi' | 'dot' | 'rampart' | 'kurenaido';
  bgMode: 'none' | 'plate' | 'cinematic';
  visualMode: VisualMode;
}

export interface CaptionTrack {
  languageCode: string;
  kind?: string;
  name: {
    simpleText?: string;
    runs?: Array<{ text: string }>;
  };
}

export interface TimedTextJson {
  events?: Array<{
    tStartMs?: string | number;
    dDurationMs?: string | number;
    segs?: Array<{ utf8?: string }>;
  }>;
}

export interface DropdownOption {
  label: string;
  value: string;
}

export interface DropdownContainerElement extends HTMLDivElement {
  updateOptions?: (options: DropdownOption[]) => void;
  setValue?: (value: string) => void;
}

export interface OutsideClickBinding {
  root: HTMLElement;
  onOutsideClick: () => void;
}

// 基準版のグローバル変数をそのまま集約した共有状態。
// DOM id、ストレージキー、デフォルト値の互換性はここを起点に守る。旧バージョンからのデータ引き継ぎで不整合を起こさないための措置。
export const state = {
  // 現在の歌詞データと、ユーザーが与えた全体オフセット。
  // リフレッシュレートの違いなどで動画時間と歌詞が微妙にずれる環境でも、ユーザー自身で手軽に微調整できるようにするため。
  lyricsData: [] as LyricsLine[],
  globalOffset: 0,
  // エディタ / 設定モーダルの開閉状態。
  isEditorOpen: false,
  isSettingsOpen: false,
  offsetToastTimer: null as number | null,
  // 手動スクロールやドラッグ中は自動追従を止めるための操作状態。
  // ユーザーが歌詞を遡って読んでいる最中に、再生中の現在位置へ強制的にスクロールされてしまうストレスを防ぐため。
  isUserInteracting: false,
  interactionTimer: null as number | null,
  manualScrollOffset: 0,
  isDraggingPos: false,
  dragStartY: 0,
  dragStartPos: 0,
  hasMoved: false,
  // 再生バー付近の安全領域は「最新ポインタ位置」と「前回計算結果」を使って、必要時だけヒット判定を切り替える。
  // 毎フレーム DOM 計測や style 書き込みを行わずに済むよう、判定に必要な最小限のキャッシュをここへ集約する。
  lastPointerClientY: null as number | null,
  controlsSafeTop: null as number | null,
  controlsSafeAreaDirty: true,
  lastWrapperPointerEvents: null as '' | 'auto' | 'none' | null,
  // エディタ内でキーボードショートカットを有効にするモード
  isShortcutModeOn: false,
  // YouTube 字幕 URL の観測結果と、そこから復元するトラック情報。
  latestTimedTextUrl: null as string | null,
  timedTextObserver: null as PerformanceObserver | null,
  availableTracks: [] as CaptionTrack[],
  rawSubtitleData: [] as RawSubtitleLine[],
  // 表示設定はストレージ永続化の対象で、未保存項目はこのデフォルト値が基準になる。
  // 初回起動時や新規設定項目が追加されたアップデート直後でも、表示が壊れないよう安全なフォールバックを確保する意図。
  userSettings: {
    isEnabled: false,
    isManuallyDisabled: true,
    fontSize: 28,
    verticalPos: 50,
    horizontalPos: 50,
    layoutPreset: 'center',
    textAlign: 'center',
    anchorY: 'center',
    visibleLines: 3,
    lineHeight: 140,
    primaryLang: 'auto',
    secondaryLang: 'ja',
    fontFamily: 'serif',
    bgMode: 'none',
    visualMode: 'normal'
  } as UserSettings,
  // 補助 UI の遅延処理や、動画ごとのカテゴリ判定キャッシュ。
  settingsOverflowTimer: null as number | null,
  syncLoopStarted: false,
  categoryCache: {} as Record<string, boolean>,
  currentVIdForCategory: null as string | null,
  uiCleanupFns: [] as Array<() => void>,
  outsideClickBindings: [] as OutsideClickBinding[]
};

// DOM 参照の型付けを簡潔に保つための小さなヘルパー。
export function byId<T extends HTMLElement = HTMLElement>(id: string): T | null {
  return document.getElementById(id) as T | null;
}
